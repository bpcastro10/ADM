def mul(a,b):\n    return a*b\n
